{{/*
Expand the name of the chart.
*/}}
{{- define "mdai-console.name" -}}
{{- default .Chart.Name .Values.nameOverride | trunc 63 | trimSuffix "-" }}
{{- end }}

{{/*
Create a default fully qualified app name.
We truncate at 63 chars because some Kubernetes name fields are limited to this (by the DNS naming spec).
If release name contains chart name it will be used as a full name.
*/}}
{{- define "mdai-console.fullname" -}}
{{- if .Values.fullnameOverride }}
{{- .Values.fullnameOverride | trunc 63 | trimSuffix "-" }}
{{- else }}
{{- $name := default .Chart.Name .Values.nameOverride }}
{{- if contains $name .Release.Name }}
{{- .Release.Name | trunc 63 | trimSuffix "-" }}
{{- else }}
{{- printf "%s-%s" .Release.Name $name | trunc 63 | trimSuffix "-" }}
{{- end }}
{{- end }}
{{- end }}

{{/*
Create chart name and version as used by the chart label.
*/}}
{{- define "mdai-console.chart" -}}
{{- printf "%s-%s" .Chart.Name .Chart.Version | replace "+" "_" | trunc 63 | trimSuffix "-" }}
{{- end }}

{{/*
Common labels
*/}}
{{- define "mdai-console.labels" -}}
helm.sh/chart: {{ include "mdai-console.chart" . }}
{{ include "mdai-console.selectorLabels" . }}
{{- if .Chart.AppVersion }}
app.kubernetes.io/version: {{ .Chart.AppVersion | quote }}
{{- end }}
app.kubernetes.io/managed-by: {{ .Release.Service }}
date: {{ now | unixEpoch | quote }}
{{- end }}

{{/*
Selector labels
*/}}
{{- define "mdai-console.selectorLabels" -}}
app.kubernetes.io/name: {{ include "mdai-console.name" . }}
app.kubernetes.io/instance: {{ .Release.Name }}
{{- end }}

{{/*
Create the name of the service account to use
*/}}
{{- define "mdai-console.serviceAccountName" -}}
{{- if .Values.serviceAccount.create }}
{{- default (include "mdai-console.fullname" .) .Values.serviceAccount.name }}
{{- else }}
{{- default "default" .Values.serviceAccount.name }}
{{- end }}
{{- end }}

{{- define "mdai-console.auth-idp-cognito" -}}
{{- $dict := dict "UserPoolArn" .Values.ingress.userPoolArn "UserPoolClientId" .Values.ingress.userPoolClientId "UserPoolDomain" .Values.ingress.userPoolDomain }}
{{- toJson $dict -}}
{{- end -}}